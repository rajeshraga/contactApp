package com.contactApp.action;

import java.util.List;
import java.util.Map;

import org.apache.struts2.ServletActionContext;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.contactApp.beans.provideUserService;

public class DeleteUserAction {
	
	private String uid;
	private Map<Integer,Boolean> userchkList;
	private List<UserInfoData> userdata;
	public List<UserInfoData> getUserdata() {
		return userdata;
	}

	public void setUserdata(List<UserInfoData> userdata) {
		this.userdata = userdata;
	}

	public Map<Integer, Boolean> getUserchkList() {
		return userchkList;
	}

	public String execute() {
		System.out.println("here we have delete request");		
		setUserchkList(userchkList);
		WebApplicationContext context = WebApplicationContextUtils.getRequiredWebApplicationContext(ServletActionContext.getServletContext());
		
		provideUserService UsrService = (provideUserService)context.getBean("provideUserService");
		int i = Integer.parseInt(uid);
		UsrService.deleteUsersFromList(ServletActionContext.getRequest(), i);
		
	
		return "success";
	}

	public void setUserchkList(Map<Integer, Boolean> userchkList) {
		this.userchkList = userchkList;
	}

	
	

}
