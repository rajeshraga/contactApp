package com.contactApp.action;

import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.contactApp.beans.loadMessageBean;
import com.contactApp.beans.provideUserService;
import com.opensymphony.xwork2.ActionContext;

public class WelcomeUserAction {

	private String username;
	private String password;
	private provideUserService usrService;
	
	public void setUsrService(provideUserService usrService) {
		this.usrService = usrService;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String execute() {
		//System.out.println("inside execute method");
		boolean authUser = false;
		
		WebApplicationContext context = WebApplicationContextUtils.getRequiredWebApplicationContext(ServletActionContext.getServletContext());
		
		provideUserService UsrService = (provideUserService)context.getBean("provideUserService");
		authUser = UsrService.getAuthUsers(getUsername(), getPassword(), ServletActionContext.getRequest());
		if(authUser)
			return "success";
		else
			return "failure";
		
	}
}
