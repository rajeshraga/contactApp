package com.contactApp.action;

import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;

public class UpdateUserAction {
	
	private String uid;
	private UserInfoData updateduserdata;

	public String getUid() {
		return uid;
	}
	public void setUid(String uid) {
		this.uid = uid;
	}
	public String execute() {
		
		int ikey = -1;
		if(getUid() != null)
			ikey = Integer.parseInt(getUid());
		
		System.out.println(getUid());
		if(ikey > 0) {
			HttpSession session = ServletActionContext.getRequest().getSession();
			HashMap<Integer, UserInfoData> mapEx = (HashMap<Integer, UserInfoData>)session.getAttribute("mapUsr");
			
			UserInfoData data = (UserInfoData)mapEx.get(ikey);
			setUpdateduserdata(data);
		}
		return "success";
	}
	public UserInfoData getUpdateduserdata() {
		return updateduserdata;
	}
	public void setUpdateduserdata(UserInfoData updateduserdata) {
		this.updateduserdata = updateduserdata;
	}
	

}
