package com.contactApp.beans;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.security.Principal;
import java.util.Collection;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;

import javax.servlet.AsyncContext;
import javax.servlet.DispatcherType;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletInputStream;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;



import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpRequest;

import com.contactApp.action.DeleteUserAction;
import com.contactApp.action.UserInfoData;

public class provideUserService extends loadMessageBean {
	
	@Autowired HttpSession session;
	
	private static Logger log;
	private static HashMap<String, String> authmap;
	static {
		log = LogManager.getLogger(provideUserService.class.getName());
		 authmap = getAuthUserInfo();
	}
	
	public provideUserService() {
		
	}
	public boolean getAuthUserId(String userid) {
		
		if(authmap != null) {
			if(authmap.get("u1").equalsIgnoreCase(userid.trim()) || authmap.get("u2").equalsIgnoreCase(userid.trim())) {
				
				log.debug("userID is authenticated");
				return true;
			
			}
			else {
				log.error("userID is not authenticated, so returning false");
				return false;
			}
		
		}
		else {
			log.debug("Authentication failure, issue here " );
			return false;
		}
				
	}
	
	public boolean getAuthPassword(String password) {
		
		if(authmap != null) {
			if(authmap.get("p1").equalsIgnoreCase(password.trim()) || authmap.get("p2").equalsIgnoreCase(password.trim())) {
				
				log.debug("password is authenticated");
				return true;
			
			}
			else {
				log.error("password is not authenticated, so returning false");
				return false;
			}
		
		}
		else {
			log.debug("Authentication failure, issue here " );
			return false;
		}
				
	}
		
	public boolean getSessionInfo(String userid, String password, HttpServletRequest request) {
		
		HttpSession session= request.getSession();
		
		try {
				if(session.isNew()) {
					//this is a new session 
					if(userid == null || password == null ) return false;
					log.debug("new session " +session.getId());
					//session.setAttribute(arg0, arg1);
					HashMap<Integer, UserInfoData> mapUser = new HashMap<>();
					session.setAttribute("mapUsr", mapUser);
					
				}
				else {
					//existing session for this user
					log.debug("existing session " +session.getId());
					HashMap<Integer, UserInfoData> mapEx = (HashMap<Integer, UserInfoData>)session.getAttribute("mapUsr");
				
					if(mapEx == null) {
						log.debug("session map attribute is empty, so setting the new Map attribute and returning that the user is authenticated");
						HashMap<Integer, UserInfoData> mapUser = new HashMap<>();	
						session.setAttribute("mapUsr", mapUser);
						
					}
					
				}
		}
		catch(Exception ex) {
			log.error("exception in setting up session object in getSessionInfo() " +ex);
			return false;
		}
		
		
		return true;
		
	}
	
	public static HashMap<String, String> getAuthUserInfo() {
		Properties prop = new Properties();
		InputStream input = null;
		input = loadMessageBean.class.getClassLoader().getResourceAsStream("authconfig.properties");
		if(input == null) {
			log.error("unable to find file authconfig.properties");
			return null;
		}
		
		try {
			prop.load(input);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			log.error("error loading property file" + input);
			e.printStackTrace();
		}
		//System.out.println(prop.getProperty("dbuser1"));
		HashMap<String, String> authuser = new HashMap<String,String>();
		authuser.put("u1", prop.getProperty("dbuser1"));
		authuser.put("u2", prop.getProperty("dbuser2"));
		authuser.put("p1", prop.getProperty("dbpassword1"));
		authuser.put("p2", prop.getProperty("dbpassword2"));
		
		return authuser;
		
	}
	
	public void addUserInfo(UserInfoData data, HttpServletRequest request) throws Exception {
		
		HttpSession session= request.getSession();
		HashMap<Integer, UserInfoData> mapEx = (HashMap<Integer, UserInfoData>)session.getAttribute("mapUsr");
		int iCount = 0;
		try {
			if(mapEx != null){
				iCount = mapEx.size();
				log.debug("Session Map count here " +iCount);
				mapEx.put(Integer.parseInt(data.getUid()), data);
				
				session.setAttribute("mapUsr", mapEx);
			}
		}
		catch(Exception ex) {
			log.error("error in addUserInfo() " +ex);
			
		}
		
	}
	
	public boolean getUserListPresent(HttpServletRequest request) {
		
		HttpSession session = request.getSession(false);
		if(session != null) {
			HashMap<Integer, UserInfoData> mapEx = (HashMap<Integer, UserInfoData>)session.getAttribute("mapUsr");
			if(mapEx.size() > 0) {
				//there are currently users in the list, so return true
				log.debug("there are currently users in the list for an existing session, so return true");
				return true;
			}
			else {
				log.debug("currently no users in existing session, return false");
				return false;
			}
		}
		else {
			log.debug("New session, so no users in list, return false");
			return false; //since for a new user session, the user list would be empty
		}
			
		
	}
	
	public void deleteUsersFromList(HttpServletRequest request, List<String> delList) {
		HttpSession session= request.getSession();
		HashMap<Integer, UserInfoData> mapEx = (HashMap<Integer, UserInfoData>)session.getAttribute("mapUsr");
		
		try {
			if(!delList.isEmpty()) {
				for(String s : delList) {
					if(s!= null && !s.trim().equalsIgnoreCase(""))
						mapEx.remove(Integer.parseInt(s));
				}		
				
			}
			
			//Now update the session object
			session.setAttribute("mapUsr", mapEx);
		}
		catch (Exception ex) {
			log.error("Exception while deleting users from list " +ex) ;
		}
		
		
	}
	
	public boolean updateUser(UserInfoData updatedData, HttpServletRequest request) throws Exception {
		log.debug("inside update user function");
		
				
		if(updatedData != null) {
			
			try {
				HttpSession session = request.getSession();
				HashMap<Integer, UserInfoData> mapEx = (HashMap<Integer, UserInfoData>)session.getAttribute("mapUsr");
				mapEx.remove(Integer.parseInt(updatedData.getUid()));
				mapEx.put(Integer.parseInt(updatedData.getUid()),updatedData);
				
				session.setAttribute("mapUsr", mapEx);
			}
			catch(Exception ex) {
				log.error("exception while updateUser()" + ex);
				return false;
			}
			
			
		
		}
		
		return true;
	}

}
